# 🛍️ Cyber Store — Vue 3

Интернет-магазин техники Apple на Vue 3 + Pinia + Vue Router.

## Структура проекта

```
src/
├── assets/
│   └── global.css          # Глобальные стили
├── components/
│   ├── layout/
│   │   ├── AppHeader.vue   # Шапка с поиском, корзиной, избранным
│   │   └── AppFooter.vue   # Футер с колонками
│   └── ui/
│       ├── ProductCard.vue  # Карточка товара
│       └── FiltersSidebar.vue # Сайдбар фильтров
├── views/
│   ├── HomeView.vue         # Главная страница
│   ├── CatalogView.vue      # Каталог с фильтрами и сортировкой
│   ├── ProductView.vue      # Страница товара
│   ├── CartView.vue         # Корзина
│   └── FavoritesView.vue   # Избранное
├── stores/
│   └── index.js             # Pinia: products, cart, favorites
├── router/
│   └── index.js             # Vue Router
├── App.vue
└── main.js
```

## Запуск

### 1. Установить зависимости
```bash
npm install
```

### 2. Запустить бэкенд (опционально)
Клонируй и запусти согласно README:
https://github.com/Arsen4ik/apple-store-backend/tree/build

Если бэкенд недоступен — работает на mock-данных автоматически.

### 3. Запустить фронтенд
```bash
npm run dev
```

Откроется на http://localhost:5173

## Функционал

- ✅ **Каталог** — список товаров с карточками
- ✅ **Поиск** — по названию, бренду (в шапке, live)
- ✅ **Фильтры** — цена, бренд, память
- ✅ **Сортировка** — по цене, рейтингу
- ✅ **Пагинация** — по 8 товаров
- ✅ **Корзина** — добавление, изменение кол-ва, удаление
- ✅ **Избранное** — добавление/удаление
- ✅ **Страница товара** — детали, отзывы, покупка
- ✅ **Хранилище** — localStorage (корзина и избранное сохраняются)
- ✅ **Роутинг** — Vue Router с 5 маршрутами
- ✅ **Адаптивность** — mobile + desktop

## Требования КТ

| Требование | Реализация |
|---|---|
| Фреймворк (Angular/Vue) | Vue 3 Composition API |
| Роутинг | vue-router/index.js |
| Хранилище | pinia/stores/index.js |
| Стилизация по макету | ✅ чёрно-белый UI, Space Grotesk |
| Поиск, корзина, фавориты, фильтры | ✅ полностью |
| Компоненты в папках | ✅ components/ui, components/layout |
| UI компоненты | ProductCard, FiltersSidebar |
| Бэкенд-сервер | fetch к localhost:3000, fallback на mock |
