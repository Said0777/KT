<template>
  <aside class="filters">
    <div class="filters__header">
      <h3>Фильтры</h3>
      <button class="filters__reset" @click="resetFilters">Сбросить</button>
    </div>

    <!-- Price Range -->
    <div class="filters__section">
      <h4 class="filters__section-title" @click="toggle('price')">
        Price <span>{{ open.price ? '▲' : '▼' }}</span>
      </h4>
      <div v-if="open.price" class="filters__price">
        <div class="filters__price-inputs">
          <div class="filters__price-field">
            <label>From</label>
            <input type="number" v-model.number="priceMin" @change="applyPrice" :max="priceMax" />
          </div>
          <div class="filters__price-field">
            <label>To</label>
            <input type="number" v-model.number="priceMax" @change="applyPrice" :min="priceMin" />
          </div>
        </div>
        <input
          type="range"
          v-model.number="priceMax"
          :min="0" :max="5000" step="50"
          @change="applyPrice"
          class="filters__range"
        />
      </div>
    </div>

    <!-- Brands -->
    <div class="filters__section" v-if="brands.length">
      <h4 class="filters__section-title" @click="toggle('brands')">
        Brand <span>{{ open.brands ? '▲' : '▼' }}</span>
      </h4>
      <div v-if="open.brands" class="filters__checks">
        <label v-for="brand in brands" :key="brand" class="filters__check">
          <input type="checkbox" :value="brand" v-model="selectedBrands" @change="applyBrands" />
          <span>{{ brand }}</span>
          <span class="filters__count">{{ brandCount(brand) }}</span>
        </label>
      </div>
    </div>

    <!-- Memory -->
    <div class="filters__section" v-if="memoryOptions.length">
      <h4 class="filters__section-title" @click="toggle('memory')">
        Storage <span>{{ open.memory ? '▲' : '▼' }}</span>
      </h4>
      <div v-if="open.memory" class="filters__tabs">
        <button
          v-for="mem in memoryOptions"
          :key="mem"
          class="filters__tab"
          :class="{ active: selectedMemory.includes(mem) }"
          @click="toggleMemory(mem)"
        >
          {{ mem }}
        </button>
      </div>
    </div>
  </aside>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useProductsStore } from '@/stores/index.js'

const store = useProductsStore()

const brands = computed(() => store.brands)
const memoryOptions = computed(() => store.memoryOptions)

const priceMin = ref(store.priceRange.min)
const priceMax = ref(store.priceRange.max || 3000)
const selectedBrands = ref([...store.selectedBrands])
const selectedMemory = ref([...store.selectedMemory])

const open = ref({ price: true, brands: true, memory: true })

function toggle(key) { open.value[key] = !open.value[key] }

function applyPrice() {
  store.priceRange = { min: priceMin.value, max: priceMax.value }
}

function applyBrands() {
  store.selectedBrands = [...selectedBrands.value]
}

function toggleMemory(mem) {
  const idx = selectedMemory.value.indexOf(mem)
  if (idx >= 0) selectedMemory.value.splice(idx, 1)
  else selectedMemory.value.push(mem)
  store.selectedMemory = [...selectedMemory.value]
}

function brandCount(brand) {
  return store.products.filter(p => p.brand === brand).length
}

function resetFilters() {
  priceMin.value = 0
  priceMax.value = 3000
  selectedBrands.value = []
  selectedMemory.value = []
  store.priceRange = { min: 0, max: 10000 }
  store.selectedBrands = []
  store.selectedMemory = []
}
</script>

<style scoped>
.filters { width: 240px; flex-shrink: 0; }
.filters__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}
.filters__header h3 { font-size: 1rem; font-weight: 700; }
.filters__reset {
  font-size: 0.8rem;
  color: var(--gray-500);
  text-decoration: underline;
  transition: var(--transition);
}
.filters__reset:hover { color: var(--black); }
.filters__section {
  border-top: 1px solid var(--gray-200);
  padding: 16px 0;
}
.filters__section-title {
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  margin-bottom: 12px;
  user-select: none;
}
.filters__price-inputs {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
}
.filters__price-field {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.filters__price-field label {
  font-size: 0.75rem;
  color: var(--gray-500);
}
.filters__price-field input {
  width: 100%;
  padding: 8px;
  border: 1px solid var(--gray-200);
  border-radius: var(--radius);
  font-size: 0.875rem;
  outline: none;
}
.filters__price-field input:focus { border-color: var(--black); }
.filters__range {
  width: 100%;
  accent-color: var(--black);
}
.filters__checks {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.filters__check {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: 0.875rem;
}
.filters__check input { accent-color: var(--black); }
.filters__count {
  margin-left: auto;
  font-size: 0.75rem;
  color: var(--gray-400);
}
.filters__tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.filters__tab {
  padding: 6px 12px;
  border: 1px solid var(--gray-200);
  border-radius: var(--radius);
  font-size: 0.8rem;
  transition: var(--transition);
}
.filters__tab.active, .filters__tab:hover {
  background: var(--black);
  color: var(--white);
  border-color: var(--black);
}
</style>
