<template>
  <div class="catalog">
    <div class="container">
      <div class="catalog__top">
        <h1 class="catalog__title">Каталог</h1>
        <div class="catalog__controls">
          <span class="catalog__count">{{ filteredProducts.length }} товаров</span>
          <select v-model="sortBy" class="catalog__sort" @change="applySort">
            <option value="default">По умолчанию</option>
            <option value="price-asc">Цена ↑</option>
            <option value="price-desc">Цена ↓</option>
            <option value="rating">По рейтингу</option>
          </select>
        </div>
      </div>

      <div class="catalog__body">
        <!-- Filters -->
        <FiltersSidebar class="catalog__filters" />

        <!-- Grid -->
        <div class="catalog__main">
          <!-- Loading -->
          <div v-if="loading" class="products-grid">
            <div v-for="i in 8" :key="i" class="skeleton-card"></div>
          </div>

          <!-- Empty -->
          <div v-else-if="!filteredProducts.length" class="catalog__empty">
            <p>🔍 Ничего не найдено</p>
            <button @click="resetSearch">Сбросить фильтры</button>
          </div>

          <!-- Products -->
          <div v-else class="products-grid">
            <ProductCard v-for="p in paginatedProducts" :key="p.id" :product="p" />
          </div>

          <!-- Pagination -->
          <div v-if="totalPages > 1" class="pagination">
            <button
              class="pagination__btn"
              :disabled="page === 1"
              @click="page--"
            >‹</button>
            <button
              v-for="p in totalPages"
              :key="p"
              class="pagination__btn"
              :class="{ active: p === page }"
              @click="page = p"
            >{{ p }}</button>
            <button
              class="pagination__btn"
              :disabled="page === totalPages"
              @click="page++"
            >›</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { useProductsStore } from '@/stores/index.js'
import ProductCard from '@/components/ui/ProductCard.vue'
import FiltersSidebar from '@/components/ui/FiltersSidebar.vue'

const store = useProductsStore()
const loading = computed(() => store.loading)
const filteredProducts = computed(() => store.filteredProducts)
const sortBy = ref(store.sortBy)

const page = ref(1)
const perPage = 8

const totalPages = computed(() => Math.ceil(filteredProducts.value.length / perPage))
const paginatedProducts = computed(() => {
  const start = (page.value - 1) * perPage
  return filteredProducts.value.slice(start, start + perPage)
})

watch(filteredProducts, () => { page.value = 1 })

function applySort() {
  store.sortBy = sortBy.value
}

function resetSearch() {
  store.searchQuery = ''
  store.selectedBrands = []
  store.selectedMemory = []
  store.priceRange = { min: 0, max: 10000 }
}

onMounted(() => {
  if (!store.products.length) store.fetchProducts()
})
</script>

<style scoped>
.catalog { padding: 40px 0 64px; }
.catalog__top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 32px;
}
.catalog__title { font-size: 1.75rem; font-weight: 700; }
.catalog__controls {
  display: flex;
  align-items: center;
  gap: 16px;
}
.catalog__count { font-size: 0.875rem; color: var(--gray-500); }
.catalog__sort {
  padding: 8px 12px;
  border: 1px solid var(--gray-200);
  border-radius: var(--radius);
  font-size: 0.875rem;
  font-family: var(--font);
  outline: none;
  cursor: pointer;
  transition: var(--transition);
}
.catalog__sort:focus { border-color: var(--black); }
.catalog__body {
  display: flex;
  gap: 32px;
  align-items: flex-start;
}
.catalog__main { flex: 1; min-width: 0; }
.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}
.skeleton-card {
  height: 340px;
  background: linear-gradient(90deg, var(--gray-100) 25%, var(--gray-200) 50%, var(--gray-100) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 12px;
}
@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
.catalog__empty {
  text-align: center;
  padding: 80px 20px;
  color: var(--gray-500);
}
.catalog__empty p { font-size: 1.2rem; margin-bottom: 16px; }
.catalog__empty button {
  padding: 10px 24px;
  background: var(--black);
  color: var(--white);
  border-radius: var(--radius);
  font-weight: 600;
  transition: var(--transition);
}
.catalog__empty button:hover { opacity: 0.8; }
.pagination {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin-top: 40px;
}
.pagination__btn {
  width: 36px;
  height: 36px;
  border: 1px solid var(--gray-200);
  border-radius: var(--radius);
  font-size: 0.875rem;
  font-weight: 500;
  transition: var(--transition);
  display: flex;
  align-items: center;
  justify-content: center;
}
.pagination__btn:hover:not(:disabled) {
  border-color: var(--black);
}
.pagination__btn.active {
  background: var(--black);
  color: var(--white);
  border-color: var(--black);
}
.pagination__btn:disabled { opacity: 0.3; cursor: not-allowed; }
@media (max-width: 768px) {
  .catalog__filters { display: none; }
  .catalog__top { flex-direction: column; align-items: flex-start; gap: 12px; }
}
</style>
