import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

const API_BASE = 'http://localhost:3000'

// ─── Products Store ───────────────────────────────────────────────
export const useProductsStore = defineStore('products', () => {
  const products = ref([])
  const loading = ref(false)
  const error = ref(null)
  const searchQuery = ref('')
  const sortBy = ref('default')
  const priceRange = ref({ min: 0, max: 10000 })
  const selectedBrands = ref([])
  const selectedMemory = ref([])

  async function fetchProducts(params = {}) {
    loading.value = true
    error.value = null
    try {
      const query = new URLSearchParams()
      if (params.search) query.set('search', params.search)
      if (params.sort) query.set('sort', params.sort)
      const url = `${API_BASE}/products${query.toString() ? '?' + query.toString() : ''}`
      const res = await fetch(url)
      if (!res.ok) throw new Error('Server error')
      products.value = await res.json()
    } catch (e) {
      error.value = e.message
      // Fallback mock data if backend unavailable
      products.value = getMockProducts()
    } finally {
      loading.value = false
    }
  }

  async function fetchProduct(id) {
    try {
      const res = await fetch(`${API_BASE}/products/${id}`)
      if (!res.ok) throw new Error('Not found')
      return await res.json()
    } catch {
      return getMockProducts().find(p => p.id == id) || null
    }
  }

  const filteredProducts = computed(() => {
    let list = [...products.value]

    if (searchQuery.value) {
      const q = searchQuery.value.toLowerCase()
      list = list.filter(p =>
        p.name?.toLowerCase().includes(q) ||
        p.title?.toLowerCase().includes(q) ||
        p.brand?.toLowerCase().includes(q)
      )
    }

    if (selectedBrands.value.length) {
      list = list.filter(p => selectedBrands.value.includes(p.brand))
    }

    if (selectedMemory.value.length) {
      list = list.filter(p => selectedMemory.value.includes(p.memory))
    }

    list = list.filter(p => {
      const price = p.price || 0
      return price >= priceRange.value.min && price <= priceRange.value.max
    })

    if (sortBy.value === 'price-asc') list.sort((a, b) => a.price - b.price)
    if (sortBy.value === 'price-desc') list.sort((a, b) => b.price - a.price)
    if (sortBy.value === 'rating') list.sort((a, b) => (b.rating || 0) - (a.rating || 0))

    return list
  })

  const brands = computed(() => [...new Set(products.value.map(p => p.brand).filter(Boolean))])
  const memoryOptions = computed(() => [...new Set(products.value.map(p => p.memory).filter(Boolean))])

  function getMockProducts() {
    return [
      { id: 1, name: 'Apple iPhone 14 Pro Max 128GB Deep Purple', brand: 'Apple', price: 1399, oldPrice: 1599, rating: 4.8, reviews: 125, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-14-pro-finish-select-202209-6-7inch-deeppurple?wid=400&hei=400&fmt=jpeg', memory: '128GB', inStock: true },
      { id: 2, name: 'Apple iPhone 14 Pro Max 256GB Deep Purple', brand: 'Apple', price: 1599, oldPrice: null, rating: 4.9, reviews: 98, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-14-pro-finish-select-202209-6-7inch-deeppurple?wid=400&hei=400&fmt=jpeg', memory: '256GB', inStock: true },
      { id: 3, name: 'Apple iPhone 13 128GB Midnight', brand: 'Apple', price: 899, oldPrice: 999, rating: 4.7, reviews: 340, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-13-finish-select-202207-6-1inch-midnight?wid=400&hei=400&fmt=jpeg', memory: '128GB', inStock: true },
      { id: 4, name: 'Apple iPhone 15 Pro 256GB Natural Titanium', brand: 'Apple', price: 1799, oldPrice: null, rating: 4.9, reviews: 67, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-15-pro-finish-select-202309-6-1inch-naturaltitanium?wid=400&hei=400&fmt=jpeg', memory: '256GB', inStock: false },
      { id: 5, name: 'Apple iPad Pro 11" 256GB Space Gray', brand: 'Apple', price: 1099, oldPrice: 1199, rating: 4.8, reviews: 156, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/ipad-pro-11-select-wifi-spacegray-202210?wid=400&hei=400&fmt=jpeg', memory: '256GB', inStock: true },
      { id: 6, name: 'Apple MacBook Pro 14" M3 512GB Space Black', brand: 'Apple', price: 2499, oldPrice: null, rating: 5.0, reviews: 43, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mbp14-spaceblack-select-202311?wid=400&hei=400&fmt=jpeg', memory: '512GB', inStock: true },
      { id: 7, name: 'Apple Watch Series 9 45mm Midnight', brand: 'Apple', price: 499, oldPrice: 549, rating: 4.6, reviews: 210, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MQDY3ref_VW_34FR+watch-45-alum-midnight-nc-9s_VW_34FR_WF_CO?wid=400&hei=400&fmt=jpeg', memory: null, inStock: true },
      { id: 8, name: 'Apple AirPods Pro 2nd Generation', brand: 'Apple', price: 299, oldPrice: 329, rating: 4.8, reviews: 487, image: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MQD83?wid=400&hei=400&fmt=jpeg', memory: null, inStock: true },
    ]
  }

  return {
    products, loading, error,
    searchQuery, sortBy, priceRange, selectedBrands, selectedMemory,
    filteredProducts, brands, memoryOptions,
    fetchProducts, fetchProduct
  }
})

// ─── Cart Store ───────────────────────────────────────────────────
export const useCartStore = defineStore('cart', () => {
  const items = ref(JSON.parse(localStorage.getItem('cart') || '[]'))

  function save() {
    localStorage.setItem('cart', JSON.stringify(items.value))
  }

  function addItem(product) {
    const existing = items.value.find(i => i.id === product.id)
    if (existing) {
      existing.quantity++
    } else {
      items.value.push({ ...product, quantity: 1 })
    }
    save()
  }

  function removeItem(id) {
    items.value = items.value.filter(i => i.id !== id)
    save()
  }

  function updateQuantity(id, qty) {
    const item = items.value.find(i => i.id === id)
    if (item) {
      if (qty <= 0) removeItem(id)
      else item.quantity = qty
    }
    save()
  }

  function clearCart() {
    items.value = []
    save()
  }

  const total = computed(() => items.value.reduce((s, i) => s + i.price * i.quantity, 0))
  const count = computed(() => items.value.reduce((s, i) => s + i.quantity, 0))
  const isInCart = (id) => items.value.some(i => i.id === id)

  return { items, total, count, isInCart, addItem, removeItem, updateQuantity, clearCart }
})

// ─── Favorites Store ──────────────────────────────────────────────
export const useFavoritesStore = defineStore('favorites', () => {
  const items = ref(JSON.parse(localStorage.getItem('favorites') || '[]'))

  function save() {
    localStorage.setItem('favorites', JSON.stringify(items.value))
  }

  function toggle(product) {
    const idx = items.value.findIndex(i => i.id === product.id)
    if (idx >= 0) items.value.splice(idx, 1)
    else items.value.push(product)
    save()
  }

  const isFavorite = (id) => items.value.some(i => i.id === id)
  const count = computed(() => items.value.length)

  return { items, count, isFavorite, toggle }
})
