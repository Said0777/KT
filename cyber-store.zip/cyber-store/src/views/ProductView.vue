<template>
  <div class="product-page">
    <div class="container">
      <!-- Breadcrumb -->
      <nav class="breadcrumb">
        <RouterLink to="/">Главная</RouterLink>
        <span>/</span>
        <RouterLink to="/catalog">Каталог</RouterLink>
        <span>/</span>
        <span>{{ product?.name || 'Товар' }}</span>
      </nav>

      <div v-if="loading" class="product-page__skeleton">
        <div class="skeleton skeleton--image"></div>
        <div class="skeleton skeleton--info"></div>
      </div>

      <div v-else-if="!product" class="not-found">
        <p>Товар не найден</p>
        <RouterLink to="/catalog">← Вернуться в каталог</RouterLink>
      </div>

      <div v-else class="product-page__body">
        <!-- Left: Image -->
        <div class="product-page__gallery">
          <div class="product-page__image-main">
            <img :src="product.image" :alt="product.name" @error="onImgError" />
          </div>
          <!-- Fav -->
          <button
            class="product-page__fav"
            :class="{ active: isFav }"
            @click="favs.toggle(product)"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" :fill="isFav ? '#ff3b3b' : 'none'" stroke="currentColor" :stroke="isFav ? '#ff3b3b' : 'currentColor'" stroke-width="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
            {{ isFav ? 'В избранном' : 'Добавить в избранное' }}
          </button>
        </div>

        <!-- Right: Info -->
        <div class="product-page__info">
          <p class="product-page__brand">{{ product.brand }}</p>
          <h1 class="product-page__title">{{ product.name || product.title }}</h1>

          <!-- Rating -->
          <div class="product-page__rating" v-if="product.rating">
            <div class="stars">
              <span v-for="i in 5" :key="i" :class="['star', { filled: i <= Math.round(product.rating) }]">★</span>
            </div>
            <span class="rating-value">{{ product.rating }}</span>
            <span class="rating-count">({{ product.reviews }} отзывов)</span>
          </div>

          <!-- Price -->
          <div class="product-page__price">
            <span class="price-current">${{ product.price }}</span>
            <span v-if="product.oldPrice" class="price-old">${{ product.oldPrice }}</span>
            <span v-if="product.oldPrice" class="price-save">
              Скидка {{ Math.round((1 - product.price / product.oldPrice) * 100) }}%
            </span>
          </div>

          <!-- Memory variants (if applicable) -->
          <div v-if="product.memory" class="product-page__options">
            <h3>Storage</h3>
            <div class="option-tabs">
              <button class="option-tab active">{{ product.memory }}</button>
            </div>
          </div>

          <!-- Stock -->
          <div class="product-page__stock" :class="product.inStock === false ? 'out' : 'in'">
            {{ product.inStock === false ? '✗ Нет в наличии' : '✓ В наличии' }}
          </div>

          <!-- CTA -->
          <div class="product-page__cta">
            <button
              class="cta-btn cta-btn--cart"
              :class="{ 'in-cart': isInCart }"
              @click="handleCart"
              :disabled="product.inStock === false"
            >
              {{ isInCart ? '✓ В корзине' : 'Добавить в корзину' }}
            </button>
            <RouterLink v-if="isInCart" to="/cart" class="cta-btn cta-btn--checkout">
              Перейти в корзину →
            </RouterLink>
          </div>

          <!-- Specs -->
          <div class="product-page__specs">
            <h3>Характеристики</h3>
            <div class="spec-row" v-if="product.memory">
              <span>Память</span><span>{{ product.memory }}</span>
            </div>
            <div class="spec-row" v-if="product.brand">
              <span>Бренд</span><span>{{ product.brand }}</span>
            </div>
            <div class="spec-row">
              <span>Артикул</span><span>{{ product.id }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Reviews -->
      <div v-if="product" class="reviews">
        <h2 class="reviews__title">Отзывы</h2>
        <div class="reviews__summary">
          <div class="reviews__overall">
            <div class="reviews__score">{{ product.rating || 4.8 }}</div>
            <div class="stars large">
              <span v-for="i in 5" :key="i" :class="['star', { filled: i <= Math.round(product.rating || 4.8) }]">★</span>
            </div>
            <div class="reviews__count">of {{ product.reviews || 125 }} reviews</div>
          </div>
          <div class="reviews__bar">
            <div class="reviews__bar-row">
              <span>Excellent</span>
              <div class="reviews__bar-track">
                <div class="reviews__bar-fill" style="width: 75%"></div>
              </div>
              <span class="reviews__bar-num">{{ product.reviews || 156 }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useProductsStore, useCartStore, useFavoritesStore } from '@/stores/index.js'

const route = useRoute()
const store = useProductsStore()
const cart = useCartStore()
const favs = useFavoritesStore()

const product = ref(null)
const loading = ref(true)

const isFav = computed(() => product.value ? favs.isFavorite(product.value.id) : false)
const isInCart = computed(() => product.value ? cart.isInCart(product.value.id) : false)

function handleCart() {
  if (!isInCart.value) cart.addItem(product.value)
}
function onImgError(e) {
  e.target.src = 'https://via.placeholder.com/400x400?text=No+Image'
}

onMounted(async () => {
  loading.value = true
  product.value = await store.fetchProduct(route.params.id)
  loading.value = false
})
</script>

<style scoped>
.product-page { padding: 32px 0 64px; }
.breadcrumb {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.85rem;
  color: var(--gray-500);
  margin-bottom: 32px;
}
.breadcrumb a:hover { color: var(--black); }
.product-page__body {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 64px;
  align-items: flex-start;
}
.product-page__gallery { position: sticky; top: 80px; }
.product-page__image-main {
  background: var(--gray-100);
  border-radius: 16px;
  padding: 40px;
  display: flex;
  justify-content: center;
  margin-bottom: 16px;
}
.product-page__image-main img {
  max-height: 360px;
  object-fit: contain;
}
.product-page__fav {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--gray-500);
  font-size: 0.875rem;
  font-weight: 500;
  transition: var(--transition);
  padding: 8px 0;
}
.product-page__fav:hover, .product-page__fav.active { color: var(--accent); }
.product-page__brand {
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: var(--gray-400);
  margin-bottom: 8px;
}
.product-page__title {
  font-size: 1.5rem;
  font-weight: 700;
  line-height: 1.3;
  margin-bottom: 16px;
}
.product-page__rating {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 24px;
}
.stars { display: flex; gap: 2px; }
.star { color: var(--gray-300); font-size: 1.1rem; }
.star.filled { color: #f59e0b; }
.stars.large .star { font-size: 1.5rem; }
.rating-value { font-weight: 700; }
.rating-count { font-size: 0.85rem; color: var(--gray-500); }
.product-page__price {
  display: flex;
  align-items: baseline;
  gap: 12px;
  margin-bottom: 24px;
}
.price-current { font-size: 2rem; font-weight: 700; }
.price-old { font-size: 1.1rem; color: var(--gray-400); text-decoration: line-through; }
.price-save {
  font-size: 0.8rem;
  background: #fee2e2;
  color: var(--accent);
  padding: 4px 8px;
  border-radius: 4px;
  font-weight: 600;
}
.product-page__options { margin-bottom: 20px; }
.product-page__options h3 { font-size: 0.9rem; font-weight: 600; margin-bottom: 10px; }
.option-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
.option-tab {
  padding: 8px 16px;
  border: 1.5px solid var(--black);
  border-radius: var(--radius);
  font-size: 0.875rem;
  font-weight: 600;
  background: var(--black);
  color: var(--white);
}
.product-page__stock {
  font-size: 0.875rem;
  font-weight: 600;
  padding: 8px 16px;
  border-radius: var(--radius);
  margin-bottom: 24px;
  display: inline-block;
}
.product-page__stock.in { background: #dcfce7; color: #166534; }
.product-page__stock.out { background: #fee2e2; color: #991b1b; }
.product-page__cta {
  display: flex;
  gap: 12px;
  flex-direction: column;
  margin-bottom: 32px;
}
.cta-btn {
  width: 100%;
  padding: 16px;
  border-radius: var(--radius);
  font-size: 1rem;
  font-weight: 700;
  text-align: center;
  transition: var(--transition);
}
.cta-btn--cart {
  background: var(--black);
  color: var(--white);
  border: none;
}
.cta-btn--cart:hover:not(:disabled):not(.in-cart) { opacity: 0.8; }
.cta-btn--cart.in-cart { background: var(--gray-200); color: var(--gray-600); }
.cta-btn--cart:disabled { opacity: 0.4; cursor: not-allowed; }
.cta-btn--checkout {
  display: block;
  background: var(--white);
  color: var(--black);
  border: 2px solid var(--black);
}
.cta-btn--checkout:hover { background: var(--black); color: var(--white); }
.product-page__specs h3 {
  font-size: 0.9rem;
  font-weight: 700;
  margin-bottom: 12px;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--gray-500);
}
.spec-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid var(--gray-100);
  font-size: 0.875rem;
}
.spec-row span:first-child { color: var(--gray-500); }
.spec-row span:last-child { font-weight: 600; }
/* Reviews */
.reviews { margin-top: 64px; border-top: 1px solid var(--gray-200); padding-top: 40px; }
.reviews__title { font-size: 1.25rem; font-weight: 700; margin-bottom: 24px; }
.reviews__summary { display: flex; gap: 48px; align-items: center; }
.reviews__overall { text-align: center; }
.reviews__score { font-size: 3rem; font-weight: 700; line-height: 1; margin-bottom: 8px; }
.reviews__count { font-size: 0.8rem; color: var(--gray-500); margin-top: 4px; }
.reviews__bar { flex: 1; }
.reviews__bar-row { display: flex; align-items: center; gap: 12px; font-size: 0.85rem; }
.reviews__bar-track {
  flex: 1;
  height: 8px;
  background: var(--gray-200);
  border-radius: 4px;
  overflow: hidden;
}
.reviews__bar-fill { height: 100%; background: #f59e0b; border-radius: 4px; }
.reviews__bar-num { color: var(--gray-500); min-width: 30px; text-align: right; }
/* Skeleton */
.product-page__skeleton { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; }
.skeleton { border-radius: 16px; background: linear-gradient(90deg, var(--gray-100) 25%, var(--gray-200) 50%, var(--gray-100) 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; }
.skeleton--image { aspect-ratio: 1; }
.skeleton--info { height: 400px; }
@keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
.not-found { text-align: center; padding: 80px; color: var(--gray-500); }
.not-found a { display: block; margin-top: 16px; color: var(--black); font-weight: 600; }
@media (max-width: 768px) {
  .product-page__body { grid-template-columns: 1fr; gap: 32px; }
  .product-page__gallery { position: static; }
}
</style>
