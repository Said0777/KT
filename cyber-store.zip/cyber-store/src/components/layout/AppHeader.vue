<template>
  <header class="header">
    <div class="container header__inner">
      <!-- Logo -->
      <RouterLink to="/" class="header__logo">
        <span class="logo-icon">⌥</span>cyber
      </RouterLink>

      <!-- Search -->
      <div class="header__search">
        <svg class="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
        </svg>
        <input
          v-model="searchQuery"
          @input="onSearch"
          type="text"
          placeholder="Search"
          class="header__search-input"
        />
      </div>

      <!-- Actions -->
      <div class="header__actions">
        <RouterLink to="/favorites" class="header__action-btn" :class="{ active: favCount > 0 }">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
          </svg>
          <span v-if="favCount" class="badge">{{ favCount }}</span>
        </RouterLink>
        <RouterLink to="/cart" class="header__action-btn" :class="{ active: cartCount > 0 }">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
          </svg>
          <span v-if="cartCount" class="badge">{{ cartCount }}</span>
        </RouterLink>
      </div>

      <!-- Burger (mobile) -->
      <button class="header__burger" @click="mobileOpen = !mobileOpen">
        <span></span><span></span><span></span>
      </button>
    </div>

    <!-- Mobile nav -->
    <div v-if="mobileOpen" class="header__mobile-nav">
      <RouterLink to="/" @click="mobileOpen = false">Главная</RouterLink>
      <RouterLink to="/catalog" @click="mobileOpen = false">Каталог</RouterLink>
      <RouterLink to="/favorites" @click="mobileOpen = false">Избранное</RouterLink>
      <RouterLink to="/cart" @click="mobileOpen = false">Корзина</RouterLink>
    </div>
  </header>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '@/stores/index.js'
import { useFavoritesStore } from '@/stores/index.js'
import { useProductsStore } from '@/stores/index.js'

const router = useRouter()
const cart = useCartStore()
const favs = useFavoritesStore()
const productsStore = useProductsStore()

const mobileOpen = ref(false)
const searchQuery = ref('')

const cartCount = computed(() => cart.count)
const favCount = computed(() => favs.count)

let searchTimer = null
function onSearch() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => {
    productsStore.searchQuery = searchQuery.value
    if (router.currentRoute.value.name !== 'Catalog') {
      router.push('/catalog')
    }
  }, 300)
}
</script>

<style scoped>
.header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: var(--white);
  border-bottom: 1px solid var(--gray-200);
}
.header__inner {
  display: flex;
  align-items: center;
  gap: 24px;
  height: 64px;
}
.header__logo {
  font-size: 1.25rem;
  font-weight: 700;
  letter-spacing: -0.5px;
  display: flex;
  align-items: center;
  gap: 4px;
  white-space: nowrap;
}
.logo-icon { font-style: normal; }
.header__search {
  flex: 1;
  max-width: 480px;
  position: relative;
}
.search-icon {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--gray-400);
  pointer-events: none;
}
.header__search-input {
  width: 100%;
  padding: 10px 12px 10px 40px;
  border: 1px solid var(--gray-200);
  border-radius: var(--radius);
  font-size: 0.9rem;
  background: var(--gray-100);
  transition: var(--transition);
  outline: none;
}
.header__search-input:focus {
  border-color: var(--black);
  background: var(--white);
}
.header__actions {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-left: auto;
}
.header__action-btn {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: var(--radius);
  color: var(--gray-500);
  transition: var(--transition);
}
.header__action-btn:hover, .header__action-btn.active {
  background: var(--gray-100);
  color: var(--black);
}
.badge {
  position: absolute;
  top: 4px;
  right: 4px;
  background: var(--accent);
  color: white;
  font-size: 0.6rem;
  font-weight: 700;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.header__burger {
  display: none;
  flex-direction: column;
  gap: 5px;
  padding: 8px;
}
.header__burger span {
  display: block;
  width: 22px;
  height: 2px;
  background: var(--black);
  border-radius: 1px;
}
.header__mobile-nav {
  display: flex;
  flex-direction: column;
  padding: 16px 24px;
  border-top: 1px solid var(--gray-200);
  gap: 12px;
}
.header__mobile-nav a {
  font-weight: 500;
  padding: 8px 0;
  border-bottom: 1px solid var(--gray-100);
}
@media (max-width: 640px) {
  .header__search { display: none; }
  .header__burger { display: flex; }
  .header__actions { margin-left: auto; }
}
</style>
