<template>
  <div class="product-card">
    <!-- Favorite -->
    <button
      class="product-card__fav"
      :class="{ active: isFav }"
      @click.prevent="favs.toggle(product)"
      aria-label="Toggle favorite"
    >
      <svg width="18" height="18" viewBox="0 0 24 24" :fill="isFav ? '#ff3b3b' : 'none'" stroke="currentColor" :stroke="isFav ? '#ff3b3b' : 'currentColor'" stroke-width="2">
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
      </svg>
    </button>

    <!-- Image -->
    <RouterLink :to="`/product/${product.id}`" class="product-card__image-wrap">
      <img
        :src="product.image"
        :alt="product.name || product.title"
        class="product-card__image"
        loading="lazy"
        @error="onImgError"
      />
    </RouterLink>

    <!-- Info -->
    <div class="product-card__body">
      <RouterLink :to="`/product/${product.id}`" class="product-card__name">
        {{ product.name || product.title }}
      </RouterLink>

      <div class="product-card__price-row">
        <span class="product-card__price">${{ product.price }}</span>
        <span v-if="product.oldPrice" class="product-card__old-price">${{ product.oldPrice }}</span>
      </div>

      <button
        class="product-card__btn"
        :class="{ 'in-cart': isInCart }"
        @click="handleCart"
        :disabled="!product.inStock && product.inStock !== undefined"
      >
        {{ isInCart ? 'В корзине ✓' : (product.inStock === false ? 'Нет в наличии' : 'Buy Now') }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useCartStore, useFavoritesStore } from '@/stores/index.js'

const props = defineProps({
  product: { type: Object, required: true }
})

const cart = useCartStore()
const favs = useFavoritesStore()

const isFav = computed(() => favs.isFavorite(props.product.id))
const isInCart = computed(() => cart.isInCart(props.product.id))

function handleCart() {
  if (isInCart.value) return
  cart.addItem(props.product)
}

function onImgError(e) {
  e.target.src = 'https://via.placeholder.com/300x300?text=No+Image'
}
</script>

<style scoped>
.product-card {
  background: var(--white);
  border: 1px solid var(--gray-200);
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  transition: box-shadow var(--transition);
  display: flex;
  flex-direction: column;
}
.product-card:hover {
  box-shadow: 0 8px 24px rgba(0,0,0,0.1);
}
.product-card__fav {
  position: absolute;
  top: 12px;
  right: 12px;
  z-index: 2;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--white);
  border-radius: 50%;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  color: var(--gray-400);
  transition: var(--transition);
}
.product-card__fav:hover, .product-card__fav.active {
  color: var(--accent);
}
.product-card__image-wrap {
  display: block;
  background: var(--gray-100);
  aspect-ratio: 1;
  overflow: hidden;
}
.product-card__image {
  width: 100%;
  height: 100%;
  object-fit: contain;
  padding: 16px;
  transition: transform 0.3s ease;
}
.product-card:hover .product-card__image {
  transform: scale(1.04);
}
.product-card__body {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  flex: 1;
}
.product-card__name {
  font-size: 0.875rem;
  font-weight: 500;
  line-height: 1.4;
  color: var(--black);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  transition: var(--transition);
}
.product-card__name:hover { opacity: 0.7; }
.product-card__price-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-top: auto;
}
.product-card__price {
  font-size: 1.1rem;
  font-weight: 700;
}
.product-card__old-price {
  font-size: 0.85rem;
  color: var(--gray-400);
  text-decoration: line-through;
}
.product-card__btn {
  width: 100%;
  padding: 10px;
  background: var(--black);
  color: var(--white);
  border-radius: var(--radius);
  font-size: 0.875rem;
  font-weight: 600;
  transition: var(--transition);
  margin-top: 8px;
}
.product-card__btn:hover:not(:disabled) {
  background: var(--gray-600);
}
.product-card__btn.in-cart {
  background: var(--gray-200);
  color: var(--gray-600);
}
.product-card__btn:disabled {
  background: var(--gray-200);
  color: var(--gray-400);
  cursor: not-allowed;
}
</style>
