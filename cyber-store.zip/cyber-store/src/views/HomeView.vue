<template>
  <div class="home">
    <!-- Hero -->
    <section class="hero">
      <div class="container hero__inner">
        <div class="hero__content">
          <p class="hero__label">Новинки 2024</p>
          <h1 class="hero__title">Лучшая техника<br /><span>по лучшим ценам</span></h1>
          <p class="hero__sub">iPhone, iPad, MacBook и аксессуары Apple с гарантией и быстрой доставкой</p>
          <div class="hero__actions">
            <RouterLink to="/catalog" class="hero__btn hero__btn--primary">Смотреть каталог</RouterLink>
            <RouterLink to="/catalog" class="hero__btn">Новинки →</RouterLink>
          </div>
        </div>
        <div class="hero__image">
          <img src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-15-pro-finish-select-202309-6-1inch-naturaltitanium?wid=600&hei=600&fmt=jpeg" alt="iPhone 15 Pro" />
        </div>
      </div>
    </section>

    <!-- Categories -->
    <section class="categories">
      <div class="container">
        <h2 class="section-title">Категории</h2>
        <div class="categories__grid">
          <RouterLink v-for="cat in categories" :key="cat.name" to="/catalog" class="category-card">
            <div class="category-card__icon">{{ cat.icon }}</div>
            <span>{{ cat.name }}</span>
          </RouterLink>
        </div>
      </div>
    </section>

    <!-- Featured Products -->
    <section class="featured">
      <div class="container">
        <div class="featured__header">
          <h2 class="section-title">Популярные товары</h2>
          <RouterLink to="/catalog" class="featured__all">Смотреть все →</RouterLink>
        </div>
        <div v-if="loading" class="loading-grid">
          <div v-for="i in 4" :key="i" class="skeleton-card"></div>
        </div>
        <div v-else class="products-grid">
          <ProductCard v-for="p in featured" :key="p.id" :product="p" />
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useProductsStore } from '@/stores/index.js'
import ProductCard from '@/components/ui/ProductCard.vue'

const store = useProductsStore()

const loading = computed(() => store.loading)
const featured = computed(() => store.products.slice(0, 4))

const categories = [
  { name: 'Phones', icon: '📱' },
  { name: 'Tablets', icon: '📟' },
  { name: 'Laptops', icon: '💻' },
  { name: 'Watches', icon: '⌚' },
  { name: 'Headphones', icon: '🎧' },
  { name: 'Cameras', icon: '📷' },
]

onMounted(() => {
  if (!store.products.length) store.fetchProducts()
})
</script>

<style scoped>
/* Hero */
.hero {
  background: var(--black);
  color: var(--white);
  padding: 80px 0;
  overflow: hidden;
}
.hero__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 48px;
  align-items: center;
}
.hero__label {
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: var(--gray-400);
  margin-bottom: 16px;
}
.hero__title {
  font-size: clamp(2rem, 4vw, 3.5rem);
  font-weight: 700;
  line-height: 1.1;
  letter-spacing: -1px;
  margin-bottom: 20px;
}
.hero__title span { color: var(--gray-400); }
.hero__sub {
  font-size: 1rem;
  color: var(--gray-400);
  line-height: 1.6;
  margin-bottom: 32px;
  max-width: 400px;
}
.hero__actions {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.hero__btn {
  padding: 14px 28px;
  border-radius: var(--radius);
  font-weight: 600;
  font-size: 0.9rem;
  transition: var(--transition);
  border: 1px solid var(--white);
  color: var(--white);
}
.hero__btn--primary {
  background: var(--white);
  color: var(--black);
}
.hero__btn--primary:hover { background: var(--gray-200); }
.hero__btn:not(.hero__btn--primary):hover { background: rgba(255,255,255,0.1); }
.hero__image {
  display: flex;
  justify-content: center;
}
.hero__image img {
  max-height: 400px;
  object-fit: contain;
  filter: drop-shadow(0 20px 40px rgba(0,0,0,0.5));
}

/* Categories */
.categories {
  padding: 64px 0;
  background: var(--gray-100);
}
.section-title {
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 24px;
}
.categories__grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 12px;
}
.category-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 20px 12px;
  background: var(--white);
  border-radius: 12px;
  border: 1px solid var(--gray-200);
  font-size: 0.85rem;
  font-weight: 500;
  transition: var(--transition);
}
.category-card:hover {
  border-color: var(--black);
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
.category-card__icon { font-size: 1.75rem; }

/* Featured */
.featured { padding: 64px 0; }
.featured__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 32px;
}
.featured__all {
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--gray-500);
  transition: var(--transition);
}
.featured__all:hover { color: var(--black); }
.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 20px;
}
.loading-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}
.skeleton-card {
  height: 360px;
  background: linear-gradient(90deg, var(--gray-100) 25%, var(--gray-200) 50%, var(--gray-100) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 12px;
}
@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
@media (max-width: 768px) {
  .hero__inner { grid-template-columns: 1fr; }
  .hero__image { display: none; }
  .categories__grid { grid-template-columns: repeat(3, 1fr); }
  .loading-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 480px) {
  .categories__grid { grid-template-columns: repeat(2, 1fr); }
}
</style>
