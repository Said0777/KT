<template>
  <div class="cart-page">
    <div class="container">
      <h1 class="cart-page__title">Корзина</h1>

      <div v-if="!cart.items.length" class="cart-empty">
        <p>🛒 Корзина пуста</p>
        <RouterLink to="/catalog" class="cart-empty__link">Перейти в каталог →</RouterLink>
      </div>

      <div v-else class="cart-layout">
        <!-- Items -->
        <div class="cart-items">
          <div v-for="item in cart.items" :key="item.id" class="cart-item">
            <RouterLink :to="`/product/${item.id}`" class="cart-item__image">
              <img :src="item.image" :alt="item.name" @error="e => e.target.src = 'https://via.placeholder.com/100x100'" />
            </RouterLink>

            <div class="cart-item__info">
              <RouterLink :to="`/product/${item.id}`" class="cart-item__name">
                {{ item.name || item.title }}
              </RouterLink>
              <p class="cart-item__sub">{{ item.memory || item.brand || '' }}</p>
            </div>

            <div class="cart-item__qty">
              <button @click="cart.updateQuantity(item.id, item.quantity - 1)" class="qty-btn">−</button>
              <span class="qty-value">{{ item.quantity }}</span>
              <button @click="cart.updateQuantity(item.id, item.quantity + 1)" class="qty-btn">+</button>
            </div>

            <div class="cart-item__price">${{ (item.price * item.quantity).toLocaleString() }}</div>

            <button class="cart-item__remove" @click="cart.removeItem(item.id)" aria-label="Remove">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6 6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Summary -->
        <div class="cart-summary">
          <h3 class="cart-summary__title">Итого</h3>

          <div class="cart-summary__rows">
            <div class="cart-summary__row">
              <span>Товары ({{ cart.count }})</span>
              <span>${{ cart.total.toLocaleString() }}</span>
            </div>
            <div class="cart-summary__row">
              <span>Доставка</span>
              <span class="free">Бесплатно</span>
            </div>
          </div>

          <div class="cart-summary__total">
            <span>Итого</span>
            <span>${{ cart.total.toLocaleString() }}</span>
          </div>

          <button class="cart-summary__btn" @click="checkout">
            Оформить заказ →
          </button>
          <RouterLink to="/catalog" class="cart-summary__continue">
            ← Продолжить покупки
          </RouterLink>

          <div v-if="ordered" class="cart-success">
            ✓ Заказ оформлен! Спасибо за покупку.
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useCartStore } from '@/stores/index.js'

const cart = useCartStore()
const ordered = ref(false)

function checkout() {
  ordered.value = true
  setTimeout(() => {
    cart.clearCart()
    ordered.value = false
  }, 3000)
}
</script>

<style scoped>
.cart-page { padding: 40px 0 64px; }
.cart-page__title { font-size: 1.75rem; font-weight: 700; margin-bottom: 32px; }
.cart-empty {
  text-align: center;
  padding: 80px 20px;
  color: var(--gray-500);
}
.cart-empty p { font-size: 1.25rem; margin-bottom: 16px; }
.cart-empty__link {
  font-weight: 600;
  color: var(--black);
  padding: 12px 24px;
  border: 2px solid var(--black);
  border-radius: var(--radius);
  display: inline-block;
  transition: var(--transition);
}
.cart-empty__link:hover { background: var(--black); color: var(--white); }
.cart-layout {
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 32px;
  align-items: flex-start;
}
.cart-items {
  display: flex;
  flex-direction: column;
  gap: 1px;
  background: var(--gray-200);
  border-radius: 12px;
  overflow: hidden;
}
.cart-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  background: var(--white);
}
.cart-item__image {
  width: 80px;
  height: 80px;
  flex-shrink: 0;
  background: var(--gray-100);
  border-radius: 8px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px;
}
.cart-item__image img { width: 100%; height: 100%; object-fit: contain; }
.cart-item__info { flex: 1; min-width: 0; }
.cart-item__name {
  font-size: 0.9rem;
  font-weight: 500;
  line-height: 1.4;
  display: block;
  margin-bottom: 4px;
  color: var(--black);
  transition: var(--transition);
}
.cart-item__name:hover { opacity: 0.7; }
.cart-item__sub { font-size: 0.8rem; color: var(--gray-400); }
.cart-item__qty {
  display: flex;
  align-items: center;
  gap: 8px;
  border: 1px solid var(--gray-200);
  border-radius: var(--radius);
  overflow: hidden;
}
.qty-btn {
  width: 32px;
  height: 32px;
  font-size: 1rem;
  transition: var(--transition);
  display: flex;
  align-items: center;
  justify-content: center;
}
.qty-btn:hover { background: var(--gray-100); }
.qty-value { min-width: 24px; text-align: center; font-weight: 600; font-size: 0.9rem; }
.cart-item__price { font-weight: 700; min-width: 80px; text-align: right; }
.cart-item__remove {
  color: var(--gray-400);
  padding: 6px;
  border-radius: 50%;
  transition: var(--transition);
}
.cart-item__remove:hover { background: #fee2e2; color: var(--accent); }
/* Summary */
.cart-summary {
  background: var(--white);
  border: 1px solid var(--gray-200);
  border-radius: 12px;
  padding: 24px;
  position: sticky;
  top: 80px;
}
.cart-summary__title { font-size: 1.1rem; font-weight: 700; margin-bottom: 20px; }
.cart-summary__rows {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 16px;
}
.cart-summary__row {
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
  color: var(--gray-600);
}
.free { color: #166534; font-weight: 600; }
.cart-summary__total {
  display: flex;
  justify-content: space-between;
  font-size: 1.1rem;
  font-weight: 700;
  padding: 16px 0;
  border-top: 2px solid var(--black);
  margin-bottom: 20px;
}
.cart-summary__btn {
  width: 100%;
  padding: 16px;
  background: var(--black);
  color: var(--white);
  border-radius: var(--radius);
  font-weight: 700;
  font-size: 1rem;
  transition: var(--transition);
  margin-bottom: 12px;
}
.cart-summary__btn:hover { opacity: 0.8; }
.cart-summary__continue {
  display: block;
  text-align: center;
  font-size: 0.875rem;
  color: var(--gray-500);
  transition: var(--transition);
}
.cart-summary__continue:hover { color: var(--black); }
.cart-success {
  margin-top: 16px;
  padding: 12px;
  background: #dcfce7;
  color: #166534;
  border-radius: var(--radius);
  font-size: 0.875rem;
  font-weight: 600;
  text-align: center;
}
@media (max-width: 768px) {
  .cart-layout { grid-template-columns: 1fr; }
  .cart-item { flex-wrap: wrap; }
}
</style>
