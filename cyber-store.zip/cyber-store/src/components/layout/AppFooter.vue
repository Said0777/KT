<template>
  <footer class="footer">
    <div class="container footer__inner">
      <div class="footer__brand">
        <div class="footer__logo">⌥cyber</div>
        <p class="footer__desc">We are a residential interior design firm located in Portland. Our boutique-studio offers more than</p>
        <div class="footer__social">
          <a href="#" aria-label="Twitter">𝕏</a>
          <a href="#" aria-label="Facebook">f</a>
          <a href="#" aria-label="TikTok">♪</a>
          <a href="#" aria-label="Pinterest">𝒫</a>
        </div>
      </div>

      <div class="footer__col">
        <h4 class="footer__title">Services</h4>
        <ul>
          <li><a href="#">Bonus program</a></li>
          <li><a href="#">Gift cards</a></li>
          <li><a href="#">Credit and payment</a></li>
          <li><a href="#">Service contracts</a></li>
          <li><a href="#">Non-cash account</a></li>
          <li><a href="#">Payment</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h4 class="footer__title">Assistance to the buyer</h4>
        <ul>
          <li><a href="#">Find an order</a></li>
          <li><a href="#">Terms of delivery</a></li>
          <li><a href="#">Exchange and return of goods</a></li>
          <li><a href="#">Guarantee</a></li>
          <li><a href="#">Frequently asked questions</a></li>
          <li><a href="#">Terms of use of the site</a></li>
        </ul>
      </div>
    </div>
    <div class="footer__bottom">
      <div class="container">
        <p>© {{ year }} Cyber Store. All rights reserved.</p>
      </div>
    </div>
  </footer>
</template>

<script setup>
const year = new Date().getFullYear()
</script>

<style scoped>
.footer {
  background: var(--black);
  color: var(--white);
  margin-top: auto;
}
.footer__inner {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 48px;
  padding: 64px 24px 48px;
}
.footer__logo {
  font-size: 1.25rem;
  font-weight: 700;
  margin-bottom: 16px;
}
.footer__desc {
  font-size: 0.85rem;
  color: var(--gray-400);
  line-height: 1.6;
  margin-bottom: 24px;
}
.footer__social {
  display: flex;
  gap: 16px;
}
.footer__social a {
  width: 36px;
  height: 36px;
  border: 1px solid var(--gray-600);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.9rem;
  color: var(--gray-400);
  transition: var(--transition);
}
.footer__social a:hover {
  border-color: var(--white);
  color: var(--white);
}
.footer__title {
  font-size: 0.95rem;
  font-weight: 600;
  margin-bottom: 20px;
}
.footer__col ul {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.footer__col a {
  font-size: 0.85rem;
  color: var(--gray-400);
  transition: var(--transition);
}
.footer__col a:hover { color: var(--white); }
.footer__bottom {
  border-top: 1px solid var(--gray-600);
  padding: 16px 0;
}
.footer__bottom p {
  font-size: 0.8rem;
  color: var(--gray-500);
  text-align: center;
}
@media (max-width: 768px) {
  .footer__inner {
    grid-template-columns: 1fr;
    gap: 32px;
    padding: 40px 24px;
    text-align: center;
  }
  .footer__social { justify-content: center; }
}
</style>
