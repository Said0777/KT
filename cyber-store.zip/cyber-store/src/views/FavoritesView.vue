<template>
  <div class="favorites-page">
    <div class="container">
      <h1 class="favorites-page__title">Избранное</h1>

      <div v-if="!favs.items.length" class="favorites-empty">
        <p>♡ Список избранного пуст</p>
        <RouterLink to="/catalog" class="favorites-empty__link">Перейти в каталог →</RouterLink>
      </div>

      <div v-else>
        <p class="favorites-count">{{ favs.items.length }} товаров в избранном</p>
        <div class="products-grid">
          <ProductCard v-for="p in favs.items" :key="p.id" :product="p" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useFavoritesStore } from '@/stores/index.js'
import ProductCard from '@/components/ui/ProductCard.vue'

const favs = useFavoritesStore()
</script>

<style scoped>
.favorites-page { padding: 40px 0 64px; }
.favorites-page__title { font-size: 1.75rem; font-weight: 700; margin-bottom: 8px; }
.favorites-count { color: var(--gray-500); margin-bottom: 32px; }
.favorites-empty {
  text-align: center;
  padding: 80px 20px;
  color: var(--gray-500);
}
.favorites-empty p { font-size: 1.25rem; margin-bottom: 16px; }
.favorites-empty__link {
  font-weight: 600;
  color: var(--black);
  padding: 12px 24px;
  border: 2px solid var(--black);
  border-radius: 8px;
  display: inline-block;
  transition: 0.2s;
}
.favorites-empty__link:hover { background: var(--black); color: var(--white); }
.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 20px;
}
</style>
